/* Sideline Scorekeeper: local-first, no external dependencies. */
(() => {
  'use strict';

  const DEFAULT_SCORING = {
    passYard: 0.1,
    completion: 0.5,
    passTD: 4,
    interceptionThrown: -2,
    rushYard: 0.1,
    rushTD: 6,
    reception: 1,
    receivingYard: 0.1,
    receivingTD: 6,
    interceptionCaught: 2,
    sack: 2,
    defensiveTD: 6
  };

  const STAT_FIELDS = [
    'passAttempts', 'completions', 'passingYards', 'passingTD', 'interceptionsThrown',
    'rushAttempts', 'rushingYards', 'rushingTD', 'receptions', 'receivingYards',
    'receivingTD', 'interceptions', 'sacks', 'defensiveTD'
  ];

  let db;
  let appState;
  let currentView = 'home';
  let teamFilter = 'all';
  let toastTimer;

  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  const main = $('#app-main');
  const dialog = $('#app-dialog');
  const dialogContent = $('#dialog-content');

  function makeId() {
    return (globalThis.crypto && crypto.randomUUID)
      ? crypto.randomUUID()
      : `id-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;
  }

  function clone(value) { return JSON.parse(JSON.stringify(value)); }
  function escapeHtml(value) {
    return String(value ?? '').replace(/[&<>"']/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[char]));
  }
  function number(value, fallback = 0) {
    const parsed = Number(value);
    return Number.isFinite(parsed) ? parsed : fallback;
  }
  function fmt(value) {
    const rounded = Math.round(number(value) * 10) / 10;
    return Number.isInteger(rounded) ? String(rounded) : rounded.toFixed(1);
  }
  function dateLabel(value) {
    try { return new Date(value).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' }); }
    catch { return 'Date unavailable'; }
  }
  function initial(name) { return (String(name || '?').trim().charAt(0) || '?').toUpperCase(); }
  function defaultState() {
    return { version: 1, players: [], games: [], activeGameId: null, settings: { scoring: clone(DEFAULT_SCORING) } };
  }

  function openDatabase() {
    return new Promise((resolve, reject) => {
      if (!('indexedDB' in window)) {
        reject(new Error('This browser does not support local database storage.'));
        return;
      }
      const request = indexedDB.open('sideline-scorekeeper', 1);
      request.onupgradeneeded = () => {
        const database = request.result;
        if (!database.objectStoreNames.contains('appState')) database.createObjectStore('appState', { keyPath: 'key' });
      };
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error || new Error('Could not open local storage.'));
    });
  }

  function readStoredState() {
    return new Promise((resolve, reject) => {
      const transaction = db.transaction('appState', 'readonly');
      const request = transaction.objectStore('appState').get('main');
      request.onsuccess = () => resolve(request.result ? request.result.value : null);
      request.onerror = () => reject(request.error || new Error('Could not read local data.'));
    });
  }

  function writeStoredState(value) {
    return new Promise((resolve, reject) => {
      const transaction = db.transaction('appState', 'readwrite');
      transaction.objectStore('appState').put({ key: 'main', value });
      transaction.oncomplete = () => resolve();
      transaction.onerror = () => reject(transaction.error || new Error('Could not save local data.'));
      transaction.onabort = () => reject(transaction.error || new Error('The local save was cancelled.'));
    });
  }

  function normalizeState(raw) {
    const fresh = defaultState();
    if (!raw || typeof raw !== 'object') return fresh;
    const merged = {
      ...fresh,
      ...raw,
      players: Array.isArray(raw.players) ? raw.players : [],
      games: Array.isArray(raw.games) ? raw.games : [],
      settings: {
        ...fresh.settings,
        ...(raw.settings || {}),
        scoring: { ...DEFAULT_SCORING, ...((raw.settings && raw.settings.scoring) || {}) }
      }
    };
    merged.players = merged.players.filter((p) => p && p.id).map((p) => ({ archived: false, ...p, name: String(p.name || 'Unnamed player') }));
    merged.games = merged.games.filter((g) => g && g.id).map((g) => ({
      plays: [], participants: [], team1Name: 'Team 1', team2Name: 'Team 2', status: 'completed', ...g,
      plays: Array.isArray(g.plays) ? g.plays : [],
      participants: Array.isArray(g.participants) ? g.participants : []
    }));
    if (!merged.games.some((g) => g.id === merged.activeGameId && g.status === 'active')) merged.activeGameId = null;
    return merged;
  }

  async function saveState(message) {
    try {
      await writeStoredState(appState);
      if (message) showToast(message);
      return true;
    } catch (error) {
      showToast(`Save failed: ${error.message}`, true);
      return false;
    }
  }

  function showToast(message, isError = false) {
    const region = $('#toast-region');
    const toast = document.createElement('div');
    toast.className = 'toast';
    if (isError) {
      toast.style.background = '#ffe0e5';
      toast.style.color = '#6d1828';
    }
    toast.textContent = message;
    region.append(toast);
    window.clearTimeout(toastTimer);
    toastTimer = window.setTimeout(() => toast.remove(), 2800);
    window.setTimeout(() => { if (toast.isConnected) toast.remove(); }, 5000);
  }

  function updateConnectionStatus() {
    const node = $('#connection-status');
    if (!node) return;
    const online = navigator.onLine;
    const controlled = !!(navigator.serviceWorker && navigator.serviceWorker.controller);
    if (online && controlled) node.innerHTML = '<span class="status-dot good"></span><span>Offline ready</span>';
    else if (online) node.innerHTML = '<span class="status-dot"></span><span>Online · caching</span>';
    else if (controlled) node.innerHTML = '<span class="status-dot good"></span><span>Offline mode</span>';
    else node.innerHTML = '<span class="status-dot warn"></span><span>Offline · not cached</span>';
  }

  function getPlayer(playerId) { return appState.players.find((p) => p.id === playerId) || null; }
  function getGame(gameId) { return appState.games.find((g) => g.id === gameId) || null; }
  function activeGame() { return appState.activeGameId ? getGame(appState.activeGameId) : null; }
  function participantTeam(game, playerId) {
    const participant = (game?.participants || []).find((p) => p.playerId === playerId);
    return participant ? participant.team : null;
  }
  function allGamePlayers(game) {
    return (game?.participants || []).map((item) => getPlayer(item.playerId)).filter(Boolean);
  }
  function blankStats() {
    const result = { fantasyPoints: 0, gamesPlayed: 0 };
    STAT_FIELDS.forEach((field) => { result[field] = 0; });
    return result;
  }
  function statFor(map, playerId) {
    if (!playerId) return null;
    if (!map[playerId]) map[playerId] = blankStats();
    return map[playerId];
  }

  function calculateGame(game) {
    const stats = {};
    let team1Score = 0;
    let team2Score = 0;
    const scoring = appState.settings.scoring;
    const addScore = (team, amount) => {
      if (team === 'team1') team1Score += amount;
      if (team === 'team2') team2Score += amount;
    };
    for (const play of (game?.plays || [])) {
      const yards = Math.max(0, number(play.yards));
      const td = !!play.touchdown;
      if (play.type === 'pass_complete') {
        const qb = statFor(stats, play.passerId);
        const receiver = statFor(stats, play.receiverId);
        if (qb) {
          qb.passAttempts += 1; qb.completions += 1; qb.passingYards += yards;
          if (td) qb.passingTD += 1;
          qb.fantasyPoints += yards * scoring.passYard + scoring.completion + (td ? scoring.passTD : 0);
        }
        if (receiver) {
          receiver.receptions += 1; receiver.receivingYards += yards;
          if (td) receiver.receivingTD += 1;
          receiver.fantasyPoints += scoring.reception + yards * scoring.receivingYard + (td ? scoring.receivingTD : 0);
        }
        if (td) addScore(play.scoreTeam || participantTeam(game, play.receiverId) || participantTeam(game, play.passerId), 6);
      } else if (play.type === 'pass_incomplete') {
        const qb = statFor(stats, play.passerId);
        if (qb) qb.passAttempts += 1;
      } else if (play.type === 'rush') {
        const runner = statFor(stats, play.runnerId);
        if (runner) {
          runner.rushAttempts += 1; runner.rushingYards += yards;
          if (td) runner.rushingTD += 1;
          runner.fantasyPoints += yards * scoring.rushYard + (td ? scoring.rushTD : 0);
        }
        if (td) addScore(play.scoreTeam || participantTeam(game, play.runnerId), 6);
      } else if (play.type === 'interception') {
        const qb = statFor(stats, play.qbId);
        const defender = statFor(stats, play.defenderId);
        if (qb) {
          qb.passAttempts += 1; qb.interceptionsThrown += 1;
          qb.fantasyPoints += scoring.interceptionThrown;
        }
        if (defender) {
          defender.interceptions += 1;
          defender.fantasyPoints += scoring.interceptionCaught;
          if (play.pickSix) {
            defender.defensiveTD += 1;
            defender.fantasyPoints += scoring.defensiveTD;
          }
        }
        if (play.pickSix) addScore(play.scoreTeam || participantTeam(game, play.defenderId), 6);
      } else if (play.type === 'sack') {
        const defender = statFor(stats, play.defenderId);
        if (defender) {
          defender.sacks += 1;
          defender.fantasyPoints += scoring.sack;
        }
      } else if (play.type === 'defensive_td') {
        const defender = statFor(stats, play.defenderId);
        if (defender) {
          defender.defensiveTD += 1;
          defender.fantasyPoints += scoring.defensiveTD;
        }
        addScore(play.scoreTeam || participantTeam(game, play.defenderId), 6);
      } else if (play.type === 'manual_points') {
        const player = statFor(stats, play.playerId);
        if (player) player.fantasyPoints += number(play.points);
      } else if (play.type === 'score_adjustment') {
        addScore(play.team, number(play.amount));
      }
    }
    Object.values(stats).forEach((s) => { s.fantasyPoints = Math.round(s.fantasyPoints * 10) / 10; });
    return { stats, team1Score, team2Score };
  }

  function calculateSeason() {
    const totals = {};
    for (const game of appState.games) {
      const calculated = calculateGame(game);
      for (const [playerId, stats] of Object.entries(calculated.stats)) {
        const target = statFor(totals, playerId);
        target.gamesPlayed += 1;
        STAT_FIELDS.forEach((field) => { target[field] += stats[field]; });
        target.fantasyPoints += stats.fantasyPoints;
      }
    }
    Object.values(totals).forEach((s) => { s.fantasyPoints = Math.round(s.fantasyPoints * 10) / 10; });
    return totals;
  }

  function scoreTeamOptions(game, selected) {
    return `<option value="team1" ${selected === 'team1' ? 'selected' : ''}>${escapeHtml(game.team1Name)}</option><option value="team2" ${selected === 'team2' ? 'selected' : ''}>${escapeHtml(game.team2Name)}</option>`;
  }
  function playerOptions(game, selectedId, omitId = null, includeBlank = false) {
    const players = allGamePlayers(game).filter((p) => p.id !== omitId);
    return `${includeBlank ? '<option value="">None</option>' : ''}${players.map((p) => `<option value="${escapeHtml(p.id)}" ${p.id === selectedId ? 'selected' : ''}>${escapeHtml(p.name)}</option>`).join('')}`;
  }
  function teamName(game, team) { return team === 'team1' ? game.team1Name : team === 'team2' ? game.team2Name : 'No team'; }

  function render() {
    updateConnectionStatus();
    $$('.nav-item').forEach((button) => button.classList.toggle('active', button.dataset.nav === (currentView === 'history' || currentView === 'settings' ? 'more' : currentView)));
    if (currentView === 'home') main.innerHTML = renderHome();
    else if (currentView === 'game') main.innerHTML = renderGame();
    else if (currentView === 'players') main.innerHTML = renderPlayers();
    else if (currentView === 'leaderboard') main.innerHTML = renderLeaderboard();
    else if (currentView === 'history') main.innerHTML = renderHistory();
    else if (currentView === 'settings') main.innerHTML = renderSettings();
    else if (currentView === 'more') main.innerHTML = renderMore();
  }

  function renderHome() {
    const game = activeGame();
    const season = calculateSeason();
    const totalPoints = Object.values(season).reduce((sum, s) => sum + s.fantasyPoints, 0);
    const topPlayers = appState.players.filter((p) => !p.archived).sort((a, b) => (season[b.id]?.fantasyPoints || 0) - (season[a.id]?.fantasyPoints || 0)).slice(0, 4);
    const recentGames = [...appState.games].sort((a, b) => new Date(b.createdAt || 0) - new Date(a.createdAt || 0)).slice(0, 3);
    return `
      <section class="hero"><div class="hero-content">
        <p class="eyebrow">YOUR LOCAL FOOTBALL HQ</p>
        <h1>Every play.<br>Every point.</h1>
        <p class="subhead">Fast sideline scoring, player stats, and a live scoreboard. Your game data stays on this device.</p>
        <div class="hero-actions">${game ? '<button class="btn primary" data-nav="game" type="button">Continue game <span>→</span></button>' : '<button class="btn primary" data-action="new-game" type="button">＋ Start a game</button>'}<button class="btn secondary" data-action="add-player" type="button">＋ Add player</button></div>
      </div></section>
      ${game ? renderHomeActiveGame(game) : ''}
      <div class="stats-grid">
        <div class="stat-tile"><strong>${appState.players.filter((p) => !p.archived).length}</strong><span>ACTIVE PLAYERS</span></div>
        <div class="stat-tile"><strong>${appState.games.length}</strong><span>GAMES SAVED</span></div>
        <div class="stat-tile"><strong>${fmt(totalPoints)}</strong><span>FANTASY POINTS</span></div>
      </div>
      <div class="section-title"><h2>Season leaders</h2><button class="text-link" data-nav="leaderboard" type="button">Full leaderboard →</button></div>
      ${topPlayers.length ? `<div class="card flat">${topPlayers.map((p, i) => `<div class="list-row"><span class="rank">${i + 1}</span><span class="avatar">${initial(p.name)}</span><div class="list-row-main"><strong>${escapeHtml(p.name)}</strong><small>${season[p.id]?.gamesPlayed || 0} game${(season[p.id]?.gamesPlayed || 0) === 1 ? '' : 's'} · ${fmt(season[p.id]?.receptions || 0)} REC</small></div><span class="points-value">${fmt(season[p.id]?.fantasyPoints || 0)}</span></div>`).join('')}</div>` : '<div class="empty-state"><div class="empty-icon">↗</div><strong>Your leaderboard is waiting</strong><p>Add players and record a game to see the fantasy-point race.</p></div>'}
      <div class="section-title"><h2>Recent games</h2><button class="text-link" data-nav="history" type="button">Game history →</button></div>
      ${recentGames.length ? `<div class="card flat">${recentGames.map((g) => renderGameHistoryRow(g)).join('')}</div>` : '<div class="empty-state"><div class="empty-icon">▣</div><strong>No games yet</strong><p>Your saved games will show up here.</p></div>'}
      <p class="small-text muted spacer-top">Local-first storage is active. Export a backup from More → Settings regularly.</p>
    `;
  }

  function renderHomeActiveGame(game) {
    const totals = calculateGame(game);
    return `<section class="card game-card"><div class="game-card-top"><span class="tag">LIVE GAME</span><span class="kicker">${game.participants.length} players</span></div><div class="scoreboard">${scoreSide(game, 'team1', totals)}<span class="score-divider">VS</span>${scoreSide(game, 'team2', totals)}</div><div class="toolbar-row"><button class="btn primary full" data-nav="game" type="button">Open scorekeeper →</button></div></section>`;
  }

  function scoreSide(game, team, totals) {
    const isOne = team === 'team1';
    const score = isOne ? totals.team1Score : totals.team2Score;
    const other = isOne ? totals.team2Score : totals.team1Score;
    const name = isOne ? game.team1Name : game.team2Name;
    return `<div class="score-side ${score > other ? 'winning' : ''}"><div class="team-name">${escapeHtml(name)}</div><div class="score">${fmt(score)}</div></div>`;
  }

  function renderGame() {
    const game = activeGame();
    if (!game) return `<div class="page-heading"><div><p class="eyebrow">SIDELINE MODE</p><h1>Game day.</h1><p class="subhead">Set up who's playing, then track every play from the sideline.</p></div></div>${appState.players.filter((p) => !p.archived).length ? '<div class="empty-state"><div class="empty-icon">▣</div><strong>No active game</strong><p>Start a game, choose who showed up, and assign each player to a team.</p><button class="btn primary" data-action="new-game" type="button">＋ Set up a game</button></div>' : '<div class="empty-state"><div class="empty-icon">♙</div><strong>Add your players first</strong><p>Create your player list before setting up the game.</p><button class="btn primary" data-action="add-player" type="button">＋ Add first player</button></div>'}`;
    const totals = calculateGame(game);
    const team1 = game.participants.filter((p) => p.team === 'team1').length;
    const team2 = game.participants.filter((p) => p.team === 'team2').length;
    const players = allGamePlayers(game).filter((p) => teamFilter === 'all' || participantTeam(game, p.id) === teamFilter);
    const sortedPlayers = players.sort((a, b) => (totals.stats[b.id]?.fantasyPoints || 0) - (totals.stats[a.id]?.fantasyPoints || 0));
    return `
      <div class="page-heading"><div><p class="eyebrow">LIVE SCOREKEEPER</p><h1>Game center</h1><p class="subhead">Tap a player to record what happened. Totals recalculate from the play log.</p></div><span class="tag">LIVE</span></div>
      <section class="card">
        <div class="card-head"><div><div class="kicker">THE SCOREBOARD</div><h2>${escapeHtml(game.team1Name)} <span class="muted">vs</span> ${escapeHtml(game.team2Name)}</h2></div><button class="btn ghost small" data-action="edit-game-setup" type="button">Edit teams</button></div>
        <div class="scoreboard">${scoreSideWithControls(game, 'team1', totals)}<span class="score-divider">VS</span>${scoreSideWithControls(game, 'team2', totals)}</div>
        <div class="toolbar-row"><span class="badge-muted">${team1} on ${escapeHtml(game.team1Name)}</span><span class="badge-muted">${team2} on ${escapeHtml(game.team2Name)}</span><span class="badge-muted">${game.participants.length} total</span></div>
      </section>
      <div class="game-toolbar"><button class="btn primary" data-action="undo-last" type="button" ${game.plays.length ? '' : 'disabled'}>↶ Undo last play</button><button class="btn secondary" data-action="score-adjust" type="button">± Adjust score</button><button class="btn ghost" data-action="complete-game" type="button">End game</button></div>
      <div class="section-title"><h2>Players on the field</h2><span class="kicker">Tap to score</span></div>
      <div class="team-filter"><button class="filter-chip ${teamFilter === 'all' ? 'active' : ''}" data-action="team-filter" data-filter="all" type="button">All (${game.participants.length})</button><button class="filter-chip ${teamFilter === 'team1' ? 'active' : ''}" data-action="team-filter" data-filter="team1" type="button">${escapeHtml(game.team1Name)} (${team1})</button><button class="filter-chip ${teamFilter === 'team2' ? 'active' : ''}" data-action="team-filter" data-filter="team2" type="button">${escapeHtml(game.team2Name)} (${team2})</button></div>
      ${sortedPlayers.length ? `<div class="player-grid">${sortedPlayers.map((p) => `<button class="player-tile" data-player-tile="${escapeHtml(p.id)}" type="button"><span class="team-label">${participantTeam(game, p.id) === 'team1' ? escapeHtml(game.team1Name) : escapeHtml(game.team2Name)}</span><span class="player-initial">${initial(p.name)}</span><strong>${escapeHtml(p.name)}</strong><span class="player-points">${fmt(totals.stats[p.id]?.fantasyPoints || 0)} <small>PTS</small></span></button>`).join('')}</div>` : '<div class="empty-state"><strong>No players selected</strong><p>Edit teams to add players to this game.</p><button class="btn secondary" data-action="edit-game-setup" type="button">Edit player list</button></div>'}
      <div class="section-title"><h2>Play-by-play</h2><span class="kicker">${game.plays.length} recorded</span></div>
      ${renderPlayHistory(game)}
    `;
  }

  function scoreSideWithControls(game, team, totals) {
    const isOne = team === 'team1';
    const score = isOne ? totals.team1Score : totals.team2Score;
    const other = isOne ? totals.team2Score : totals.team1Score;
    const name = isOne ? game.team1Name : game.team2Name;
    return `<div class="score-side ${score > other ? 'winning' : ''}"><div class="team-name">${escapeHtml(name)}</div><div class="score">${fmt(score)}</div><div class="team-controls"><button type="button" aria-label="Subtract one point from ${escapeHtml(name)}" data-action="quick-score" data-team="${team}" data-amount="-1">−</button><button type="button" aria-label="Add one point to ${escapeHtml(name)}" data-action="quick-score" data-team="${team}" data-amount="1">＋</button></div></div>`;
  }

  function eventDescription(game, play) {
    const person = (id) => getPlayer(id)?.name || 'Unknown player';
    const yds = `${number(play.yards)} yd${number(play.yards) === 1 ? '' : 's'}`;
    switch (play.type) {
      case 'pass_complete': return { title: `${person(play.passerId)} → ${person(play.receiverId)}`, detail: `${yds} completed pass${play.touchdown ? ' · TOUCHDOWN' : ''} · ${teamName(game, play.scoreTeam)}`, points: `+${fmt(number(play.yards) * appState.settings.scoring.passYard + appState.settings.scoring.completion + (play.touchdown ? appState.settings.scoring.passTD : 0))} QB / +${fmt(appState.settings.scoring.reception + number(play.yards) * appState.settings.scoring.receivingYard + (play.touchdown ? appState.settings.scoring.receivingTD : 0))} REC` };
      case 'pass_incomplete': return { title: `${person(play.passerId)} · Incomplete pass`, detail: 'Pass attempt recorded', points: 'No points' };
      case 'rush': return { title: `${person(play.runnerId)} · Rush`, detail: `${yds} rushing${play.touchdown ? ' · TOUCHDOWN' : ''} · ${teamName(game, play.scoreTeam)}`, points: `+${fmt(number(play.yards) * appState.settings.scoring.rushYard + (play.touchdown ? appState.settings.scoring.rushTD : 0))}` };
      case 'interception': return { title: `${person(play.defenderId)} · Interception`, detail: `${play.qbId ? `${person(play.qbId)} picked off` : 'Defensive interception'}${play.pickSix ? ' · PICK SIX' : ''} · ${teamName(game, play.scoreTeam)}`, points: `+${fmt(appState.settings.scoring.interceptionCaught + (play.pickSix ? appState.settings.scoring.defensiveTD : 0))} DEF${play.qbId ? ` / ${fmt(appState.settings.scoring.interceptionThrown)} QB` : ''}` };
      case 'sack': return { title: `${person(play.defenderId)} · Sack`, detail: 'Defensive sack', points: `+${fmt(appState.settings.scoring.sack)}` };
      case 'defensive_td': return { title: `${person(play.defenderId)} · Defensive touchdown`, detail: `Defensive score · ${teamName(game, play.scoreTeam)}`, points: `+${fmt(appState.settings.scoring.defensiveTD)}` };
      case 'manual_points': return { title: `${person(play.playerId)} · Point adjustment`, detail: play.note || 'Manual fantasy point adjustment', points: `${number(play.points) > 0 ? '+' : ''}${fmt(play.points)} PTS` };
      case 'score_adjustment': return { title: `${teamName(game, play.team)} · Score adjustment`, detail: play.note || 'Manual scoreboard correction', points: `${number(play.amount) > 0 ? '+' : ''}${fmt(play.amount)} SCORE` };
      default: return { title: 'Recorded play', detail: '', points: '' };
    }
  }

  function renderPlayHistory(game) {
    if (!game.plays.length) return '<div class="empty-state"><div class="empty-icon">↶</div><strong>No plays recorded yet</strong><p>Tap any player above to record the first play.</p></div>';
    const recent = [...game.plays].reverse().slice(0, 18);
    return `<div class="card flat">${recent.map((play) => { const d = eventDescription(game, play); return `<div class="play-row"><div class="play-main"><strong>${escapeHtml(d.title)}</strong><small>${escapeHtml(d.detail)}<br><span class="${d.points.includes('-') ? 'negative' : 'positive'}">${escapeHtml(d.points)}</span> · ${new Date(play.createdAt || Date.now()).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })}</small></div><div class="play-actions"><button type="button" data-action="edit-event" data-event-id="${escapeHtml(play.id)}">Edit</button><button type="button" class="delete-play" data-action="delete-event" data-event-id="${escapeHtml(play.id)}" aria-label="Delete play">×</button></div></div>`; }).join('')}</div>${game.plays.length > 18 ? `<p class="small-text muted">Showing the 18 most recent plays. All ${game.plays.length} remain saved.</p>` : ''}`;
  }

  function renderPlayers() {
    const players = [...appState.players].sort((a, b) => Number(a.archived) - Number(b.archived) || a.name.localeCompare(b.name));
    const season = calculateSeason();
    return `<div class="page-heading"><div><p class="eyebrow">ROSTER</p><h1>Your players</h1><p class="subhead">Add your friends once. Their names stay saved for future games.</p></div><button class="btn primary" data-action="add-player" type="button">＋ Add</button></div>
      <div class="field"><input class="search-input" id="player-search" type="search" placeholder="Search players…" aria-label="Search players"></div>
      ${players.length ? `<div class="card flat" id="player-list">${players.map((p) => `<div class="list-row" data-player-row="${escapeHtml(p.id)}"><span class="avatar">${initial(p.name)}</span><div class="list-row-main"><strong>${escapeHtml(p.name)} ${p.archived ? '<span class="badge-muted">ARCHIVED</span>' : ''}</strong><small>${fmt(season[p.id]?.fantasyPoints || 0)} season points · ${season[p.id]?.gamesPlayed || 0} games</small></div><button class="btn ghost small" data-action="player-detail" data-player-id="${escapeHtml(p.id)}" type="button">Stats</button><button class="btn ghost small" data-action="edit-player" data-player-id="${escapeHtml(p.id)}" type="button">Edit</button></div>`).join('')}</div>` : '<div class="empty-state"><div class="empty-icon">♙</div><strong>No players added</strong><p>Add the friends who play so they are ready for game day.</p><button class="btn primary" data-action="add-player" type="button">＋ Add first player</button></div>'}`;
  }

  function renderLeaderboard() {
    const season = calculateSeason();
    const players = appState.players.filter((p) => !p.archived && season[p.id]).sort((a, b) => season[b.id].fantasyPoints - season[a.id].fantasyPoints);
    return `<div class="page-heading"><div><p class="eyebrow">FANTASY RACE</p><h1>Leaderboard</h1><p class="subhead">Season totals across every saved game on this device.</p></div></div>
      ${players.length ? `<div class="card"><div class="card-head"><h2>Top performers</h2><span class="tag">SEASON</span></div>${players.map((p, i) => `<div class="list-row"><span class="rank">${String(i + 1).padStart(2, '0')}</span><span class="avatar">${initial(p.name)}</span><div class="list-row-main"><strong>${escapeHtml(p.name)}</strong><small>${fmt(season[p.id].passingYards)} pass YDS · ${fmt(season[p.id].rushingYards)} rush YDS · ${fmt(season[p.id].receivingYards)} rec YDS</small></div><span class="points-value">${fmt(season[p.id].fantasyPoints)}</span></div>`).join('')}</div>` : '<div class="empty-state"><div class="empty-icon">↗</div><strong>No points on the board</strong><p>Record some plays to build your leaderboard.</p><button class="btn primary" data-nav="game" type="button">Open scorekeeper</button></div>'}
      <div class="section-title"><h2>Stat leaders</h2><span class="kicker">SEASON TOTALS</span></div>
      ${players.length ? `<div class="card flat table-wrap"><table><thead><tr><th>Player</th><th>Pass YDS</th><th>Rush YDS</th><th>Rec YDS</th><th>TD</th><th>INT</th><th>SACK</th></tr></thead><tbody>${players.map((p) => { const s = season[p.id]; return `<tr><td><strong>${escapeHtml(p.name)}</strong></td><td>${fmt(s.passingYards)}</td><td>${fmt(s.rushingYards)}</td><td>${fmt(s.receivingYards)}</td><td>${fmt(s.passingTD + s.rushingTD + s.receivingTD + s.defensiveTD)}</td><td>${fmt(s.interceptions)}</td><td>${fmt(s.sacks)}</td></tr>`; }).join('')}</tbody></table></div>` : ''}`;
  }

  function renderGameHistoryRow(game) {
    const totals = calculateGame(game);
    const status = game.status === 'active' ? '<span class="tag">LIVE</span>' : '<span class="badge-muted">FINAL</span>';
    return `<div class="list-row"><div class="list-row-main"><strong>${escapeHtml(game.team1Name)} ${fmt(totals.team1Score)} <span class="muted">·</span> ${fmt(totals.team2Score)} ${escapeHtml(game.team2Name)}</strong><small>${dateLabel(game.createdAt)} · ${game.participants.length} players</small></div>${status}<button class="btn ghost small" data-action="view-game-history" data-game-id="${escapeHtml(game.id)}" type="button">View</button></div>`;
  }

  function renderHistory() {
    const games = [...appState.games].sort((a, b) => new Date(b.createdAt || 0) - new Date(a.createdAt || 0));
    return `<div class="page-heading"><div><p class="eyebrow">ARCHIVE</p><h1>Game history</h1><p class="subhead">Every completed game and its play log stays saved here.</p></div></div>
      ${games.length ? `<div class="card flat">${games.map((g) => renderGameHistoryRow(g)).join('')}</div>` : '<div class="empty-state"><div class="empty-icon">▣</div><strong>No saved games yet</strong><p>Your completed games will appear here.</p><button class="btn primary" data-action="new-game" type="button">Start first game</button></div>'}`;
  }

  function renderMore() {
    return `<div class="page-heading"><div><p class="eyebrow">TOOLS</p><h1>More</h1><p class="subhead">Game archive, scoring rules, offline status, and backup controls.</p></div></div>
      <div class="card flat"><button class="settings-row" style="width:100%;text-align:left;background:none;border:0;color:inherit" data-nav="history" type="button"><span><strong>Game history</strong><small>Review previous games and play logs</small></span><span class="muted">→</span></button><button class="settings-row" style="width:100%;text-align:left;background:none;border:0;color:inherit" data-nav="settings" type="button"><span><strong>Settings & backups</strong><small>Edit scoring values and protect your data</small></span><span class="muted">→</span></button></div>
      <div class="note-box spacer-top"><strong>Offline by design.</strong> After the app has loaded once online and shows “Offline ready,” you can turn on Airplane Mode and keep scoring. Game data is saved to this browser on this device.</div>`;
  }

  const SCORING_LABELS = {
    passYard: ['Passing yards', 'Points per passing yard'], completion: ['Completion', 'Points per completed pass'], passTD: ['Passing touchdown', 'Points for the passer'], interceptionThrown: ['Interception thrown', 'Points for the quarterback'],
    rushYard: ['Rushing yards', 'Points per rushing yard'], rushTD: ['Rushing touchdown', 'Points for the runner'], reception: ['Reception', 'Points per catch'], receivingYard: ['Receiving yards', 'Points per receiving yard'], receivingTD: ['Receiving touchdown', 'Points for the receiver'],
    interceptionCaught: ['Interception caught', 'Points for the defender'], sack: ['Sack', 'Points for the defender'], defensiveTD: ['Defensive touchdown', 'Points for a defensive score']
  };

  function renderSettings() {
    return `<div class="page-heading"><div><p class="eyebrow">PREFERENCES</p><h1>Settings</h1><p class="subhead">Tune your scoring system and keep a copy of your game data.</p></div></div>
      <section class="card"><div class="card-head"><div><div class="kicker">FANTASY RULES</div><h2>Scoring values</h2></div><span class="tag">EDITABLE</span></div>
        <form id="scoring-form">${Object.entries(SCORING_LABELS).map(([key, value]) => `<div class="settings-row"><span><strong>${value[0]}</strong><small>${value[1]}</small></span><input type="number" name="${key}" step="0.1" value="${escapeHtml(appState.settings.scoring[key])}" aria-label="${value[0]} points"></div>`).join('')}<button class="btn primary full spacer-top" type="submit">Save scoring rules</button></form>
      </section>
      <section class="card"><div class="card-head"><div><div class="kicker">LOCAL DATA</div><h2>Backup & restore</h2></div><span class="tag">IMPORTANT</span></div>
        <p class="subhead">Your names, games, stats, and scoring settings live in this device's browser storage. A backup file is your safety net if you change phones or clear website data.</p>
        <div class="modal-actions"><button class="btn primary" data-action="export-backup" type="button">↓ Export backup</button><button class="btn secondary" data-action="import-backup" type="button">↑ Import backup</button></div>
        <p class="small-text muted spacer-top">Export a backup after game days. The JSON file contains your scorekeeper data. Keep it somewhere you can find it.</p>
      </section>
      <section class="card flat"><div class="card-head"><h2>Offline status</h2><span class="tag">PWA</span></div>
        <div class="settings-row"><span><strong>App files cached</strong><small id="cache-status-text">Checking service worker status…</small></span><span id="cache-status" class="badge-muted">Checking</span></div>
        <div class="settings-row"><span><strong>Local database</strong><small>IndexedDB on this device</small></span><span class="badge-muted">Active</span></div>
        <div class="warning-box spacer-top"><strong>Keep in mind:</strong> deleting the installed app or clearing Safari website data can remove its local database. Export backups regularly. This app does not sync between devices.</div>
      </section>
      <p class="small-text muted spacer-top">Sideline Scorekeeper · Version 1.0 · No account, no analytics, no external scripts.</p>`;
  }

  function openDialog(title, content, eyebrow = 'SIDELINE') {
    $('#dialog-title').textContent = title;
    $('#dialog-eyebrow').textContent = eyebrow;
    dialogContent.innerHTML = content;
    if (!dialog.open) dialog.showModal();
  }
  function closeDialog() { if (dialog.open) dialog.close(); }

  function openPlayerForm(playerId = null) {
    const player = playerId ? getPlayer(playerId) : null;
    openDialog(player ? 'Edit player' : 'Add a player', `<form id="player-form" data-player-id="${player ? escapeHtml(player.id) : ''}">
      <div class="field"><label for="player-name">Player name</label><input id="player-name" name="name" maxlength="50" required placeholder="Enter their name" value="${escapeHtml(player?.name || '')}" autocomplete="off"></div>
      <div class="modal-actions"><button class="btn secondary" type="button" data-action="close-dialog">Cancel</button><button class="btn primary" type="submit">${player ? 'Save changes' : 'Add player'}</button></div>
      ${player ? `<div class="modal-actions"><button class="btn ghost" type="button" data-action="toggle-archive" data-player-id="${escapeHtml(player.id)}">${player.archived ? 'Restore player' : 'Archive player'}</button><button class="btn danger" type="button" data-action="delete-player" data-player-id="${escapeHtml(player.id)}">Delete</button></div>` : ''}
    </form>`, 'PLAYER ROSTER');
    $('#player-name')?.focus();
  }

  function openGameSetup(existing = null) {
    if (!appState.players.some((p) => !p.archived)) {
      showToast('Add at least one player first.', true);
      currentView = 'players'; render(); return;
    }
    const game = existing || null;
    const previous = new Map((game?.participants || []).map((p) => [p.playerId, p]));
    const activePlayers = appState.players.filter((p) => !p.archived || previous.has(p.id)).sort((a, b) => a.name.localeCompare(b.name));
    const defaultTeam1 = game?.team1Name || 'Team 1';
    const defaultTeam2 = game?.team2Name || 'Team 2';
    openDialog(game ? 'Edit game setup' : 'Set up a game', `<form id="game-setup-form" data-game-id="${game ? escapeHtml(game.id) : ''}">
      <div class="form-grid"><div class="field"><label for="team1-name">Team 1 name</label><input id="team1-name" name="team1Name" maxlength="30" required value="${escapeHtml(defaultTeam1)}"></div><div class="field"><label for="team2-name">Team 2 name</label><input id="team2-name" name="team2Name" maxlength="30" required value="${escapeHtml(defaultTeam2)}"></div></div>
      <div class="card-head"><h3>Who's playing?</h3><span class="kicker">Select attendees</span></div>
      <div class="dialog-content-scroll">${activePlayers.map((p) => { const old = previous.get(p.id); const checked = !!old; const team = old?.team || 'team1'; return `<div class="setup-player"><label><input type="checkbox" name="attend_${escapeHtml(p.id)}" ${checked ? 'checked' : ''}> <span>${escapeHtml(p.name)}${p.archived ? ' (archived)' : ''}</span></label><select name="team_${escapeHtml(p.id)}" aria-label="Team for ${escapeHtml(p.name)}"><option value="team1" ${team === 'team1' ? 'selected' : ''}>${escapeHtml(defaultTeam1)}</option><option value="team2" ${team === 'team2' ? 'selected' : ''}>${escapeHtml(defaultTeam2)}</option></select></div>`; }).join('')}</div>
      <p class="field-help spacer-top">Check each attendee and choose their temporary team. Their player profile stays the same for future games.</p>
      <div class="modal-actions"><button class="btn secondary" type="button" data-action="close-dialog">Cancel</button><button class="btn primary" type="submit">${game ? 'Save setup' : 'Start game'}</button></div>
    </form>`, 'GAME SETUP');
  }

  function openActionPicker(playerId) {
    const game = activeGame();
    const player = getPlayer(playerId);
    if (!game || !player) return;
    const actions = [
      ['pass_complete', 'Completed pass', 'QB + receiver, yards, optional TD'],
      ['pass_incomplete', 'Incomplete pass', 'Credit a pass attempt'],
      ['rush', 'Rushing play', 'Yards and optional TD'],
      ['interception', 'Interception', 'Defender + optional QB penalty or pick six'],
      ['sack', 'Sack', 'Defensive player gets a sack'],
      ['defensive_td', 'Defensive touchdown', 'Defensive score not from a pick'],
      ['manual_points', 'Manual fantasy points', 'Add or subtract any point amount']
    ];
    openDialog(player.name, `<p class="subhead" style="margin-bottom:14px">Choose what ${escapeHtml(player.name)} did. You can edit or undo any play later.</p><div class="action-list">${actions.map(([type, title, desc]) => `<button type="button" class="list-row" style="width:100%;text-align:left;background:none;color:inherit" data-action="record-action" data-player-id="${escapeHtml(playerId)}" data-type="${type}"><span class="avatar">${({pass_complete:'↗',pass_incomplete:'·',rush:'➜',interception:'↙',sack:'×',defensive_td:'★',manual_points:'±'})[type]}</span><span class="list-row-main"><strong>${title}</strong><small>${desc}</small></span><span class="muted">→</span></button>`).join('')}</div>`, 'RECORD A PLAY');
  }

  function renderEventForm(type, clickedPlayerId, existing = null) {
    const game = activeGame();
    const play = existing || {};
    const isEdit = !!existing;
    const playerId = clickedPlayerId || '';
    const field = (label, name, value, inputType = 'number', help = '') => `<div class="field"><label for="event-${name}">${label}</label><input id="event-${name}" name="${name}" type="${inputType}" ${inputType === 'number' ? 'step="any"' : ''} value="${escapeHtml(value ?? '')}" ${inputType === 'number' ? '' : 'maxlength="80"'} required></div>${help ? `<p class="field-help">${help}</p>` : ''}`;
    const select = (label, name, value, options, required = true) => `<div class="field"><label for="event-${name}">${label}</label><select id="event-${name}" name="${name}" ${required ? 'required' : ''}>${options}</select></div>`;
    const check = (label, name, checked) => `<label class="check-row"><input type="checkbox" name="${name}" ${checked ? 'checked' : ''}> ${label}</label>`;
    let content = '';
    let title = 'Record play';
    const participants = game.participants;
    if (type === 'pass_complete') {
      title = isEdit ? 'Edit completed pass' : 'Completed pass';
      const defaultPasser = play.passerId || playerId;
      const defaultReceiver = play.receiverId || participants.find((p) => p.playerId !== defaultPasser)?.playerId || '';
      content = `${select('Quarterback', 'passerId', defaultPasser, playerOptions(game, defaultPasser))}${select('Receiver', 'receiverId', defaultReceiver, playerOptions(game, defaultReceiver, defaultPasser))}${field('Yards gained', 'yards', play.yards ?? 0)}${check('Touchdown pass', 'touchdown', !!play.touchdown)}${select('Team credited on scoreboard', 'scoreTeam', play.scoreTeam || participantTeam(game, defaultReceiver) || 'team1', scoreTeamOptions(game, play.scoreTeam || participantTeam(game, defaultReceiver) || 'team1'))}`;
    } else if (type === 'pass_incomplete') {
      title = isEdit ? 'Edit incomplete pass' : 'Incomplete pass';
      content = select('Quarterback', 'passerId', play.passerId || playerId, playerOptions(game, play.passerId || playerId));
    } else if (type === 'rush') {
      title = isEdit ? 'Edit rushing play' : 'Rushing play';
      const runner = play.runnerId || playerId;
      content = `${select('Rusher', 'runnerId', runner, playerOptions(game, runner))}${field('Rushing yards', 'yards', play.yards ?? 0)}${check('Touchdown run', 'touchdown', !!play.touchdown)}${select('Team credited on scoreboard', 'scoreTeam', play.scoreTeam || participantTeam(game, runner) || 'team1', scoreTeamOptions(game, play.scoreTeam || participantTeam(game, runner) || 'team1'))}`;
    } else if (type === 'interception') {
      title = isEdit ? 'Edit interception' : 'Interception';
      const defender = play.defenderId || playerId;
      content = `${select('Defensive player who caught it', 'defenderId', defender, playerOptions(game, defender))}${select('Quarterback who threw it (optional)', 'qbId', play.qbId || '', playerOptions(game, play.qbId || '', defender, true), false)}${check('Pick six (interception returned for TD)', 'pickSix', !!play.pickSix)}${select('Defensive team credited on scoreboard', 'scoreTeam', play.scoreTeam || participantTeam(game, defender) || 'team1', scoreTeamOptions(game, play.scoreTeam || participantTeam(game, defender) || 'team1'))}`;
    } else if (type === 'sack') {
      title = isEdit ? 'Edit sack' : 'Sack';
      const defender = play.defenderId || playerId;
      content = select('Defensive player', 'defenderId', defender, playerOptions(game, defender));
    } else if (type === 'defensive_td') {
      title = isEdit ? 'Edit defensive touchdown' : 'Defensive touchdown';
      const defender = play.defenderId || playerId;
      content = `${select('Defensive player', 'defenderId', defender, playerOptions(game, defender))}${select('Team credited on scoreboard', 'scoreTeam', play.scoreTeam || participantTeam(game, defender) || 'team1', scoreTeamOptions(game, play.scoreTeam || participantTeam(game, defender) || 'team1'))}`;
    } else if (type === 'manual_points') {
      title = isEdit ? 'Edit point adjustment' : 'Manual fantasy points';
      content = `${select('Player', 'playerId', play.playerId || playerId, playerOptions(game, play.playerId || playerId))}${field('Points to add or subtract', 'points', play.points ?? 0)}<div class="field"><label for="event-note">Reason (optional)</label><input id="event-note" name="note" maxlength="100" value="${escapeHtml(play.note || '')}" placeholder="Correction, bonus, etc."></div>`;
    }
    openDialog(title, `<form id="event-form" data-type="${type}" data-event-id="${isEdit ? escapeHtml(play.id) : ''}">${content}<div class="modal-actions"><button class="btn secondary" type="button" data-action="close-dialog">Cancel</button><button class="btn primary" type="submit">${isEdit ? 'Save play' : 'Record play'}</button></div></form>`, 'PLAY LOG');
  }

  function openScoreAdjustForm() {
    const game = activeGame();
    if (!game) return;
    openDialog('Adjust scoreboard', `<form id="score-adjust-form"><div class="field"><label for="adjust-team">Team</label><select id="adjust-team" name="team">${scoreTeamOptions(game, 'team1')}</select></div><div class="field"><label for="adjust-amount">Points to add or subtract</label><input id="adjust-amount" name="amount" type="number" step="1" value="0" required></div><div class="field"><label for="adjust-note">Reason (optional)</label><input id="adjust-note" name="note" maxlength="100" placeholder="Score correction"></div><div class="modal-actions"><button class="btn secondary" type="button" data-action="close-dialog">Cancel</button><button class="btn primary" type="submit">Save adjustment</button></div></form>`, 'SCOREBOARD');
  }

  function openPlayerDetail(playerId) {
    const player = getPlayer(playerId);
    if (!player) return;
    const season = calculateSeason()[playerId] || blankStats();
    const rows = [
      ['Passing', `${season.completions}/${season.passAttempts} COMP/ATT`, `${fmt(season.passingYards)} YDS · ${season.passingTD} TD · ${season.interceptionsThrown} INT`],
      ['Rushing', `${season.rushAttempts} ATT`, `${fmt(season.rushingYards)} YDS · ${season.rushingTD} TD`],
      ['Receiving', `${season.receptions} REC`, `${fmt(season.receivingYards)} YDS · ${season.receivingTD} TD`],
      ['Defense', `${season.interceptions} INT · ${season.sacks} SACK`, `${season.defensiveTD} defensive TD`]
    ];
    openDialog(player.name, `<div class="stat-tile" style="margin-bottom:14px"><strong>${fmt(season.fantasyPoints)}</strong><span>SEASON FANTASY POINTS</span></div>${rows.map(([label, a, b]) => `<div class="settings-row"><span><strong>${label}</strong><small>${a} · ${b}</small></span></div>`).join('')}<div class="modal-actions"><button class="btn secondary" data-action="close-dialog" type="button">Close</button><button class="btn primary" data-action="edit-player" data-player-id="${escapeHtml(playerId)}" type="button">Edit player</button></div>`, 'PLAYER STATS');
  }

  function eventFromForm(form) {
    const data = new FormData(form);
    const type = form.dataset.type;
    const base = { id: form.dataset.eventId || makeId(), type, createdAt: form.dataset.eventId ? (activeGame().plays.find((p) => p.id === form.dataset.eventId)?.createdAt || new Date().toISOString()) : new Date().toISOString() };
    if (type === 'pass_complete') return { ...base, passerId: data.get('passerId'), receiverId: data.get('receiverId'), yards: Math.max(0, number(data.get('yards'))), touchdown: data.has('touchdown'), scoreTeam: data.get('scoreTeam') };
    if (type === 'pass_incomplete') return { ...base, passerId: data.get('passerId') };
    if (type === 'rush') return { ...base, runnerId: data.get('runnerId'), yards: Math.max(0, number(data.get('yards'))), touchdown: data.has('touchdown'), scoreTeam: data.get('scoreTeam') };
    if (type === 'interception') return { ...base, defenderId: data.get('defenderId'), qbId: data.get('qbId') || null, pickSix: data.has('pickSix'), scoreTeam: data.get('scoreTeam') };
    if (type === 'sack') return { ...base, defenderId: data.get('defenderId') };
    if (type === 'defensive_td') return { ...base, defenderId: data.get('defenderId'), scoreTeam: data.get('scoreTeam') };
    if (type === 'manual_points') return { ...base, playerId: data.get('playerId'), points: number(data.get('points')), note: String(data.get('note') || '').trim() };
    return base;
  }

  function validateEvent(play, game) {
    const participantIds = new Set(game.participants.map((p) => p.playerId));
    if (play.type === 'pass_complete') {
      if (!participantIds.has(play.passerId) || !participantIds.has(play.receiverId)) return 'Choose both the quarterback and receiver from this game.';
      if (play.passerId === play.receiverId) return 'Choose two different players for the passer and receiver.';
    }
    if (play.type === 'pass_incomplete' && !participantIds.has(play.passerId)) return 'Choose a quarterback from this game.';
    if (play.type === 'rush' && !participantIds.has(play.runnerId)) return 'Choose a rusher from this game.';
    if (play.type === 'interception') {
      if (!participantIds.has(play.defenderId)) return 'Choose a defender from this game.';
      if (play.qbId && !participantIds.has(play.qbId)) return 'Choose a quarterback from this game.';
      if (play.qbId === play.defenderId) return 'The quarterback and defender must be different players.';
    }
    if ((play.type === 'sack' || play.type === 'defensive_td') && !participantIds.has(play.defenderId)) return 'Choose a defender from this game.';
    if (play.type === 'manual_points' && !participantIds.has(play.playerId)) return 'Choose a player from this game.';
    if (play.type === 'pass_complete' || play.type === 'rush') if (number(play.yards) < 0) return 'Yards cannot be negative.';
    return null;
  }

  async function handleEventSubmit(form) {
    const game = activeGame();
    if (!game) return;
    const play = eventFromForm(form);
    const error = validateEvent(play, game);
    if (error) { showToast(error, true); return; }
    const index = game.plays.findIndex((p) => p.id === play.id);
    if (index >= 0) game.plays[index] = play;
    else game.plays.push(play);
    await saveState(index >= 0 ? 'Play updated and totals recalculated.' : 'Play recorded.');
    closeDialog(); render();
  }

  async function handleSubmit(event) {
    const form = event.target;
    if (!(form instanceof HTMLFormElement)) return;
    if (form.id === 'player-form') {
      event.preventDefault();
      const name = String(new FormData(form).get('name') || '').trim();
      if (!name) return;
      const playerId = form.dataset.playerId;
      if (playerId) getPlayer(playerId).name = name;
      else appState.players.push({ id: makeId(), name, archived: false, createdAt: new Date().toISOString() });
      await saveState(playerId ? 'Player updated.' : 'Player added.');
      closeDialog(); currentView = 'players'; render(); return;
    }
    if (form.id === 'game-setup-form') {
      event.preventDefault();
      const data = new FormData(form);
      const team1Name = String(data.get('team1Name') || '').trim();
      const team2Name = String(data.get('team2Name') || '').trim();
      if (!team1Name || !team2Name) { showToast('Enter both team names.', true); return; }
      const participants = [];
      appState.players.forEach((p) => {
        if (data.has(`attend_${p.id}`)) participants.push({ playerId: p.id, team: data.get(`team_${p.id}`) === 'team2' ? 'team2' : 'team1' });
      });
      if (participants.length < 1) { showToast('Select at least one player.', true); return; }
      const gameId = form.dataset.gameId;
      if (gameId) {
        const target = getGame(gameId);
        target.team1Name = team1Name; target.team2Name = team2Name; target.participants = participants;
      } else {
        const game = { id: makeId(), createdAt: new Date().toISOString(), status: 'active', team1Name, team2Name, participants, plays: [] };
        appState.games.push(game); appState.activeGameId = game.id;
      }
      await saveState(gameId ? 'Game setup updated.' : 'Game started. Have a good one.');
      closeDialog(); currentView = 'game'; teamFilter = 'all'; render(); return;
    }
    if (form.id === 'event-form') { event.preventDefault(); await handleEventSubmit(form); return; }
    if (form.id === 'score-adjust-form') {
      event.preventDefault();
      const data = new FormData(form);
      const amount = number(data.get('amount'));
      const game = activeGame();
      if (!game || !amount) { showToast('Enter a non-zero score adjustment.', true); return; }
      game.plays.push({ id: makeId(), type: 'score_adjustment', team: data.get('team'), amount, note: String(data.get('note') || '').trim(), createdAt: new Date().toISOString() });
      await saveState('Scoreboard adjusted.'); closeDialog(); render(); return;
    }
    if (form.id === 'scoring-form') {
      event.preventDefault();
      const data = new FormData(form);
      Object.keys(DEFAULT_SCORING).forEach((key) => { appState.settings.scoring[key] = number(data.get(key), DEFAULT_SCORING[key]); });
      await saveState('Scoring rules saved.'); render(); return;
    }
  }

  async function handleClick(event) {
    const button = event.target.closest('button, a');
    if (!button) return;
    if (button.dataset.nav) {
      event.preventDefault(); currentView = button.dataset.nav; if (currentView === 'more') currentView = 'more'; render(); return;
    }
    const action = button.dataset.action;
    if (!action) return;
    if (action === 'close-dialog') { closeDialog(); return; }
    if (action === 'new-game') { openGameSetup(); return; }
    if (action === 'add-player') { openPlayerForm(); return; }
    if (action === 'continue-game') { currentView = 'game'; render(); return; }
    if (action === 'edit-game-setup') { openGameSetup(activeGame()); return; }
    if (action === 'complete-game') {
      const game = activeGame();
      if (game && confirm('End this game? Its stats and play history will remain saved.')) {
        game.status = 'completed'; game.completedAt = new Date().toISOString(); appState.activeGameId = null;
        await saveState('Game saved to history.'); currentView = 'home'; render();
      }
      return;
    }
    if (action === 'undo-last') {
      const game = activeGame();
      if (game?.plays.length && confirm('Undo the most recent play? All affected stats and scores will be recalculated.')) {
        game.plays.pop(); await saveState('Last play undone.'); render();
      }
      return;
    }
    if (action === 'score-adjust') { openScoreAdjustForm(); return; }
    if (action === 'quick-score') {
      const game = activeGame();
      if (!game) return;
      game.plays.push({ id: makeId(), type: 'score_adjustment', team: button.dataset.team, amount: number(button.dataset.amount), note: 'Quick scoreboard adjustment', createdAt: new Date().toISOString() });
      await saveState('Score updated.'); render(); return;
    }
    if (action === 'team-filter') { teamFilter = button.dataset.filter || 'all'; render(); return; }
    if (action === 'record-action') { renderEventForm(button.dataset.type, button.dataset.playerId); return; }
    if (action === 'edit-event') {
      const game = activeGame(); const play = game?.plays.find((p) => p.id === button.dataset.eventId);
      if (play) renderEventForm(play.type, null, play); return;
    }
    if (action === 'delete-event') {
      const game = activeGame();
      if (game && confirm('Delete this play? Player stats and the scoreboard will be recalculated.')) {
        game.plays = game.plays.filter((p) => p.id !== button.dataset.eventId);
        await saveState('Play deleted.'); render();
      }
      return;
    }
    if (action === 'edit-player') { openPlayerForm(button.dataset.playerId); return; }
    if (action === 'player-detail') { openPlayerDetail(button.dataset.playerId); return; }
    if (action === 'toggle-archive') {
      const player = getPlayer(button.dataset.playerId); if (player) { player.archived = !player.archived; await saveState(player.archived ? 'Player archived.' : 'Player restored.'); closeDialog(); currentView = 'players'; render(); } return;
    }
    if (action === 'delete-player') {
      const playerId = button.dataset.playerId;
      const referenced = appState.games.some((g) => g.participants.some((p) => p.playerId === playerId) || g.plays.some((play) => Object.values(play).includes(playerId)));
      if (referenced) { showToast('This player appears in saved games. Archive them instead so old stats stay accurate.', true); return; }
      if (confirm('Permanently delete this player?')) { appState.players = appState.players.filter((p) => p.id !== playerId); await saveState('Player deleted.'); closeDialog(); currentView = 'players'; render(); }
      return;
    }
    if (action === 'view-game-history') { openGameSummary(button.dataset.gameId); return; }
    if (action === 'reopen-game') {
      const game = getGame(button.dataset.gameId);
      if (!game) return;
      if (activeGame()) { showToast('End the current live game before reopening an older one.', true); return; }
      game.status = 'active'; appState.activeGameId = game.id;
      await saveState('Game reopened. You can now edit its play log.');
      closeDialog(); currentView = 'game'; teamFilter = 'all'; render(); return;
    }
    if (action === 'export-backup') { exportBackup(); return; }
    if (action === 'import-backup') { $('#backup-file-input').click(); return; }
  }

  function openGameSummary(gameId) {
    const game = getGame(gameId);
    if (!game) return;
    const totals = calculateGame(game);
    const players = Object.entries(totals.stats).sort((a, b) => b[1].fantasyPoints - a[1].fantasyPoints);
    openDialog(`${game.team1Name} vs ${game.team2Name}`, `<div class="scoreboard">${scoreSide(game, 'team1', totals)}<span class="score-divider">VS</span>${scoreSide(game, 'team2', totals)}</div><p class="small-text muted">${dateLabel(game.createdAt)} · ${game.plays.length} plays · ${game.status === 'active' ? 'In progress' : 'Final'}</p><div class="section-title"><h2>Game leaders</h2></div>${players.length ? players.map(([id, s]) => `<div class="list-row"><span class="avatar">${initial(getPlayer(id)?.name)}</span><div class="list-row-main"><strong>${escapeHtml(getPlayer(id)?.name || 'Unknown')}</strong><small>${fmt(s.passingYards)} pass YDS · ${fmt(s.rushingYards)} rush YDS · ${fmt(s.receivingYards)} rec YDS</small></div><span class="points-value">${fmt(s.fantasyPoints)}</span></div>`).join('') : '<p class="muted small-text">No player stats recorded.</p>'}<div class="modal-actions"><button class="btn secondary" data-action="close-dialog" type="button">Close</button>${game.status === 'completed' && !activeGame() ? `<button class="btn primary" data-action="reopen-game" data-game-id="${escapeHtml(game.id)}" type="button">Reopen to edit</button>` : ''}</div>`, 'GAME SUMMARY');
  }

  async function exportBackup() {
    const backup = { app: 'Sideline Scorekeeper', exportedAt: new Date().toISOString(), data: appState };
    const blob = new Blob([JSON.stringify(backup, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = url; anchor.download = `sideline-backup-${new Date().toISOString().slice(0, 10)}.json`;
    document.body.append(anchor); anchor.click(); anchor.remove(); URL.revokeObjectURL(url);
    showToast('Backup file created. Keep it somewhere safe.');
  }

  async function importBackup(file) {
    if (!file) return;
    try {
      const text = await file.text();
      const parsed = JSON.parse(text);
      const raw = parsed?.data || parsed;
      if (!raw || !Array.isArray(raw.players) || !Array.isArray(raw.games) || !raw.settings) throw new Error('That file does not look like a Sideline backup.');
      if (!confirm('Import this backup and replace the data currently saved on this device? Export your current data first if you want to keep a copy.')) return;
      appState = normalizeState(raw);
      await saveState('Backup restored successfully.');
      currentView = 'home'; closeDialog(); render();
    } catch (error) {
      showToast(`Could not import backup: ${error.message}`, true);
    } finally {
      $('#backup-file-input').value = '';
    }
  }

  function updateCacheStatus() {
    const text = $('#cache-status-text');
    const badge = $('#cache-status');
    if (!text || !badge) return;
    if (navigator.serviceWorker?.controller) {
      text.textContent = 'Service worker is controlling this app. Core files are cached for offline launch.';
      badge.textContent = 'Cached';
    } else {
      text.textContent = 'Open this hosted app online once and wait for the status above to say Offline ready.';
      badge.textContent = 'Not ready';
    }
  }

  document.addEventListener('click', handleClick);
  document.addEventListener('submit', handleSubmit);
  document.addEventListener('click', (event) => {
    const tile = event.target.closest('[data-player-tile]');
    if (tile && !event.target.closest('button[data-action]')) openActionPicker(tile.dataset.playerTile);
  });
  document.addEventListener('input', (event) => {
    if (event.target.id === 'player-search') {
      const query = event.target.value.trim().toLowerCase();
      $$('[data-player-row]').forEach((row) => { row.classList.toggle('hidden', !row.textContent.toLowerCase().includes(query)); });
    }
  });
  $('#quick-add-player').addEventListener('click', () => openPlayerForm());
  $('.close-dialog').addEventListener('click', closeDialog);
  $('#backup-file-input').addEventListener('change', (event) => importBackup(event.target.files?.[0]));
  window.addEventListener('online', updateConnectionStatus);
  window.addEventListener('offline', updateConnectionStatus);
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.addEventListener('controllerchange', () => { updateConnectionStatus(); updateCacheStatus(); });
  }
  dialog.addEventListener('click', (event) => { if (event.target === dialog) closeDialog(); });

  async function init() {
    try {
      db = await openDatabase();
      appState = normalizeState(await readStoredState());
      await writeStoredState(appState);
      if (navigator.storage?.persist) navigator.storage.persist().catch(() => {});
      render();
      if (navigator.serviceWorker?.ready) navigator.serviceWorker.ready.then(() => { updateConnectionStatus(); updateCacheStatus(); }).catch(() => {});
      window.setTimeout(updateCacheStatus, 700);
    } catch (error) {
      main.innerHTML = `<div class="empty-state"><div class="empty-icon">!</div><strong>Local storage could not start</strong><p>${escapeHtml(error.message)} Open this app in Safari on a secure hosted address and make sure website storage is allowed.</p></div>`;
      $('#connection-status').innerHTML = '<span class="status-dot warn"></span><span>Storage error</span>';
    }
  }

  init();
})();
