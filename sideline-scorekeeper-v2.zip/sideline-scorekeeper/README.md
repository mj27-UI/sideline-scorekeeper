# Sideline Scorekeeper

A lightweight, offline-first football scorekeeper PWA. It has no account, cloud database, analytics, external runtime libraries, or paid API dependencies.

## What it does

- Stores player profiles, games, play events, and scoring rules in IndexedDB on the device.
- Tracks passing, rushing, receiving, interceptions, sacks, defensive touchdowns, and manual point adjustments.
- Calculates fantasy totals from the play log, so editing/deleting/undoing a play recalculates the stats and scoreboard.
- Tracks two real-life team scores. A completed passing touchdown adds six points to the real team once, even though both the passer and receiver earn fantasy points.
- Includes game history, season leaderboard, editable scoring, and JSON backup/restore.
- Caches its app shell using a service worker for offline launch after first online load.

## Run locally for development

Service workers require HTTPS or localhost. Do not open `index.html` as a `file://` URL.

With Python installed:

```bash
python3 -m http.server 8000
```

Then open `http://localhost:8000` in a browser.

## Publish free with GitHub Pages

GitHub Pages on GitHub Free requires a **public repository**. The source code in this project contains no player roster or game data. The actual player names, scores, and play history are saved separately in IndexedDB on the scorekeeper device and are not uploaded to the repository by this app.

1. Sign in to GitHub and create a new **public** repository, for example `sideline-scorekeeper`.
2. Upload the contents of this folder to the repository root. `index.html` should be at the top level, not nested inside another folder.
3. In the repository, open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select the `main` branch and `/ (root)`, then save.
6. Wait for GitHub Pages to publish. The URL will look like `https://YOUR-USERNAME.github.io/sideline-scorekeeper/`.

GitHub Pages documentation: https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site

## Install on iPhone

1. Open the published URL in **Safari** while online.
2. Wait until the app's status changes to **Offline ready**. This indicates that the service worker is controlling the page after caching the core files. If it initially says `Online · caching`, keep the page open for a moment or reload once.
3. In Safari, tap **Share → Add to Home Screen**. Enable **Open as Web App** if that option appears, then tap **Add**.
4. Launch the new Home Screen icon once while online.
5. Test offline by turning on Airplane Mode, opening the Home Screen app, creating a temporary player/game, recording a test play, closing and reopening the app, and checking that the data remains.
6. Delete the temporary test data or restore your real backup before using the app for a real game.

Apple's current instructions: https://support.apple.com/guide/iphone/turn-a-website-into-an-app-in-safari-on-iphone-iphea86e5236/ios

## Important data notes

- Game data is **local to the browser/app installation on this device**. It does not sync to another phone.
- Export a JSON backup regularly from **More → Settings → Export backup**.
- Importing a backup replaces the current local app data after a confirmation prompt.
- Clearing Safari website data, removing the app/site data, or device loss may remove locally stored data. Keep backup files somewhere safe.
- If you publish a changed version, refresh while online so the service worker can install the updated app shell before you need it offline.

## Offline implementation

- `sw.js` pre-caches the HTML, CSS, JS, manifest, and icon assets.
- `app.js` stores the application state in IndexedDB (`sideline-scorekeeper`, object store `appState`).
- No remote resources are required by the running app.
- The app requests persistent browser storage when supported, but browsers may not grant it. Backups are still important.
